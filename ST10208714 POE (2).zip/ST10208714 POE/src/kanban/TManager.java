/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import javax.swing.JOptionPane;

/**
 * @author Thuso Diphoko
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class TManager 
{
    String taskName, taskDescription, developersFirstName, developersLastName, taskID;
    int numberOfTasks, taskDuration;
    
    public void setTaskName(String tName)                                       //mutator method
    {                                                                           //these methods allow you to change the property
        taskName = tName;                                                       //eg TManager bob = new TManager
    }                                                                           //   bob.setValue( newValue )
    
    public String getTaskName()                                                 //accessor method
    {                                                                           //these methods 'fetch' the infomation to be used anywhere other than the object instance
        return taskName;                                                        //eg TManager bob = new TManager
    }                                                                           //   thing = bob.getValue
    
    public void setTaskDescription(String tDescription)
    {
        taskDescription = tDescription;
    }
    
    public String getTaskDescription()
    {
        return taskDescription;
    }
    
    public void setDevelopersFirstName(String dFirstName)
    {
        developersFirstName = dFirstName;
    }
    
    public String getDevelopersFirstName()
    {
        return developersFirstName;
    }
    
    public void setDevelopersLastName(String dLastName)
    {
        developersLastName = dLastName;
    }
    
    public String getDevelopersLastName()
    {
        return developersLastName;
    }
    
    public void setNumberOfTasks(int nOfTasks)
    {
        numberOfTasks = nOfTasks;
    }
    
    public int getNumberOfTasks()
    {
        return numberOfTasks;
    }
    
    public void setTaskDuration(int tDuration)
    {
        taskDuration = tDuration;
    }
    
    public int getTaskDuration()
    {
        return taskDuration;
    }                                                                           //end of accessor and mutator methods
    
    
    
    public TManager()                                                           //constructor method
    {                                                                           //this allows you to make an new 'empty' instance of TManager
        taskName = "";                                                          //eg TManger bob = new TManager()
        taskDescription = "";
        developersFirstName = "";
        developersLastName = "";
        taskID = "";
        numberOfTasks = 0;
        taskDuration = 0;
    }                                                                           //end of constructor method
    
    
    public void askTaskName()                                                   //start of 'ask' methods
    {                                                                           //these are methods that ask the user to input the value
        taskName = JOptionPane.showInputDialog(null,"What is your task name?");
    }
    
    public void askumberOfTasks()
    {
        String tasks = JOptionPane.showInputDialog(null,"How many tasks do you want to perform?");
        numberOfTasks = Integer.parseInt(tasks);
    }
    
    //finish asks
    
    
    public String taskStatus()                                                  //start of complex methods
    {
        String toDo = "To Do";   
        String done = "Done";
        String doing = "Doing";
        String taskStatus = null;
        String Status = JOptionPane.showInputDialog(null,"What is the status of your task?\n"+toDo+"\n"+done+"\n"
                       +doing,null,JOptionPane.QUESTION_MESSAGE);
        int task = Integer.parseInt(Status);

        switch(task)
        {
            case 1 : taskStatus = toDo; break;
            case 2 : taskStatus = done; break;
            case 3 : taskStatus = doing; break;
        }
        return taskStatus;
    }
    
    public String createTaskID()                                                
    {
        char a,b,c,d,e;
        int i = 0;
        a = taskName.charAt(i);
        b = developersLastName.charAt(developersLastName.length()-3);
        c = developersLastName.charAt(developersLastName.length()-2);
        d = developersLastName.charAt(developersLastName.length()-1);
        i = 1;   
        e = taskName.charAt(i);
          
        String A = String.valueOf(a);
        String B = String.valueOf(e);
        String no = String.valueOf(numberOfTasks);
        String C = String.valueOf(b);
        String D = String.valueOf(c);
        String E = String.valueOf(d);
        taskID = A+B+":"+no+":"+C+D+E;
        return taskID;
    }
    
    public int returnTotalHours(int taskDuration)
    {   
        int returnTotalHours = taskDuration;
        
        while(taskDuration <= 0)
        {
            JOptionPane.showMessageDialog(null ,returnTotalHours);
        }
        return returnTotalHours;
    }
}
