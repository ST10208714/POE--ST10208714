/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package kanban;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author lab_services_student
 */
public class taskManagerNGTest {
    
    public taskManagerNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getTaskName method, of class taskManager.
     */
    @Test
    public void testGetTaskName() {
        System.out.println("getTaskName");
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.getTaskName();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of numberOfTasks method, of class taskManager.
     */
    @Test
    public void testNumberOfTasks() {
        System.out.println("numberOfTasks");
        taskManager instance = new taskManager();
        int expResult = 0;
        int result = instance.numberOfTasks();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of TaskDescription method, of class taskManager.
     */
    @Test
    public void testTaskDescription() {
        System.out.println("TaskDescription");
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.TaskDescription();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkTaskDescription method, of class taskManager.
     */
    @Test
    public void testCheckTaskDescription() {
        System.out.println("checkTaskDescription");
        String taskDescription = "";
        taskManager instance = new taskManager();
        boolean expResult = false;
        boolean result = instance.checkTaskDescription(taskDescription);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DeveloperDetails method, of class taskManager.
     */
    @Test
    public void testDeveloperDetails() {
        System.out.println("DeveloperDetails");
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.DeveloperDetails();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskDuration method, of class taskManager.
     */
    @Test
    public void testTaskDuration() {
        System.out.println("taskDuration");
        taskManager instance = new taskManager();
        int expResult = 0;
        int result = instance.taskDuration();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createTaskID method, of class taskManager.
     */
    @Test
    public void testCreateTaskID() {
        System.out.println("createTaskID");
        String taskName = "";
        int numberOfTasks = 0;
        String developersLastName = "";
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.createTaskID(taskName, numberOfTasks, developersLastName);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskStatus method, of class taskManager.
     */
    @Test
    public void testTaskStatus() {
        System.out.println("taskStatus");
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.taskStatus();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTaskDetails method, of class taskManager.
     */
    @Test
    public void testPrintTaskDetails() {
        System.out.println("printTaskDetails");
        String taskName = "";
        String TaskID = "";
        String taskDescription = "";
        String taskStatus = "";
        taskManager instance = new taskManager();
        String expResult = "";
        String result = instance.printTaskDetails(taskName, TaskID, taskDescription, taskStatus);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of returnTotalHours method, of class taskManager.
     */
    @Test
    public void testReturnTotalHours() {
        System.out.println("returnTotalHours");
        int taskDuration = 0;
        taskManager instance = new taskManager();
        int expResult = 0;
        int result = instance.returnTotalHours(taskDuration);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
